import {
  formatDistance,
  escapeHtml,
  googleWalkingDirections
} from './utils.js';
import { NearbySearchService } from './search/nearby-search-service.js';
import { OverpassProvider } from './search/providers/overpass-provider.js';

// Composition root for the nearby-search module.
// app.js keeps using queryNearby(), so this refactor does not change the UI.
const nearbySearchService = new NearbySearchService({
  provider: new OverpassProvider()
});

export function queryNearby(anchor, radiusMeters = 900) {
  return nearbySearchService.search(anchor, radiusMeters);
}

export function nearbyCardHtml(place) {
  return `
    <b>${escapeHtml(place.name)}</b>
    <small>
      ${escapeHtml(place.amenity || 'place')} ·
      ${formatDistance(place.distance)}
    </small>
    <a
      target="_blank"
      rel="noopener"
      href="${googleWalkingDirections(place.name)}"
    >
      Directions in Google Maps →
    </a>
  `;
}
