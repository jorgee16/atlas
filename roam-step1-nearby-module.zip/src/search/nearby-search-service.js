import { distanceMeters } from '../utils.js';

export class NearbySearchService {
  constructor({ provider, cacheTtlMs = 5 * 60 * 1000 } = {}) {
    if (!provider || typeof provider.search !== 'function') {
      throw new TypeError('NearbySearchService requires a search provider.');
    }

    this.provider = provider;
    this.cacheTtlMs = cacheTtlMs;
    this.cache = new Map();
    this.pending = new Map();
  }

  async search(anchor, radiusMeters = 900) {
    const key = this.#cacheKey(anchor, radiusMeters);
    const cached = this.cache.get(key);

    if (cached && Date.now() - cached.createdAt < this.cacheTtlMs) {
      return cached.places;
    }

    if (this.pending.has(key)) {
      return this.pending.get(key);
    }

    const request = this.#searchAndSort(anchor, radiusMeters)
      .finally(() => this.pending.delete(key));

    this.pending.set(key, request);
    return request;
  }

  async #searchAndSort(anchor, radiusMeters) {
    const rawPlaces = await this.provider.search(anchor, radiusMeters);

    const places = rawPlaces
      .map(place => ({
        ...place,
        distance: distanceMeters(
          anchor.lat,
          anchor.lon,
          place.lat,
          place.lon
        )
      }))
      .sort((a, b) => a.distance - b.distance);

    this.cache.set(this.#cacheKey(anchor, radiusMeters), {
      createdAt: Date.now(),
      places
    });

    return places;
  }

  #cacheKey(anchor, radiusMeters) {
    // Rounding avoids a new request for tiny GPS movements.
    const lat = Number(anchor.lat).toFixed(3);
    const lon = Number(anchor.lon).toFixed(3);
    return `${lat}:${lon}:${radiusMeters}`;
  }
}
