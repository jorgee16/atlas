const DEFAULT_ENDPOINTS = [
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass-api.de/api/interpreter',
  'https://overpass.nchc.org.tw/api/interpreter'
];

export class OverpassProvider {
  constructor({
    endpoints = DEFAULT_ENDPOINTS,
    timeoutMs = 12000,
    fetchFn = globalThis.fetch
  } = {}) {
    this.endpoints = endpoints;
    this.timeoutMs = timeoutMs;
    this.fetchFn = fetchFn;
  }

  async search(anchor, radiusMeters = 900) {
    this.#validateAnchor(anchor);

    const query = this.#buildQuery(anchor, radiusMeters);
    let lastError = null;

    for (const endpoint of this.endpoints) {
      try {
        const data = await this.#request(endpoint, query);
        return this.#normalize(data);
      } catch (error) {
        lastError = error;
        console.warn(`Overpass endpoint failed: ${endpoint}`, error);
      }
    }

    throw new Error(
      `Nearby search failed on every OpenStreetMap endpoint. ${lastError?.message ?? ''}`.trim()
    );
  }

  async #request(endpoint, query) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeoutMs);

    try {
      const response = await this.fetchFn(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
        },
        body: new URLSearchParams({ data: query }),
        cache: 'no-store',
        signal: controller.signal
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      if (error?.name === 'AbortError') {
        throw new Error(`request timed out after ${this.timeoutMs / 1000}s`);
      }
      throw error;
    } finally {
      clearTimeout(timeoutId);
    }
  }

  #buildQuery(anchor, radiusMeters) {
    return `
      [out:json][timeout:20];
      (
        nwr["amenity"~"cafe|restaurant|fast_food|pub|bar"]
          (around:${radiusMeters},${anchor.lat},${anchor.lon});
        nwr["tourism"~"museum|gallery|attraction|viewpoint"]
          (around:${radiusMeters},${anchor.lat},${anchor.lon});
      );
      out center tags;
    `;
  }

  #normalize(data) {
    return (data.elements ?? [])
      .map(element => {
        const lat = element.lat ?? element.center?.lat;
        const lon = element.lon ?? element.center?.lon;
        const tags = element.tags ?? {};

        return {
          id: `${element.type}-${element.id}`,
          lat,
          lon,
          name: tags.name,
          amenity: tags.amenity ?? tags.tourism ?? '',
          type: this.#classify(tags)
        };
      })
      .filter(place =>
        Number.isFinite(place.lat) &&
        Number.isFinite(place.lon) &&
        Boolean(place.name)
      );
  }

  #classify(tags) {
    if (tags.amenity === 'cafe') return 'cafe';
    if (['restaurant', 'fast_food'].includes(tags.amenity)) return 'restaurant';
    if (['pub', 'bar'].includes(tags.amenity)) return 'pub';
    return 'attraction';
  }

  #validateAnchor(anchor) {
    if (!Number.isFinite(anchor?.lat) || !Number.isFinite(anchor?.lon)) {
      throw new TypeError('Nearby search requires valid latitude and longitude.');
    }
  }
}
