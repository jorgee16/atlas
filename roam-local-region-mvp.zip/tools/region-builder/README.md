# Roam Region Builder

Builds a local POI region from an OpenStreetMap `.osm.pbf` extract.

Output:

- `metadata.json`
- `pois.geojson`

The generated database is derived from OpenStreetMap and is distributed
under ODbL 1.0. Keep visible attribution to OpenStreetMap contributors.
