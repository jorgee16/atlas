import {
  formatDistance,
  escapeHtml,
  googleWalkingDirections
} from './utils.js';
import { RegionRepository } from './search/region-repository.js';
import { LocalRegionProvider } from './search/providers/local-region-provider.js';

const regionRepository = new RegionRepository();
const provider = new LocalRegionProvider({ regionRepository });

export function queryNearby(anchor, radiusMeters = 900) {
  return provider.search(anchor, radiusMeters);
}

export function nearbyCardHtml(place) {
  return `
    <b>${escapeHtml(place.name)}</b>
    <small>
      ${escapeHtml(place.amenity || 'place')} ·
      ${formatDistance(place.distance)}
    </small>
    <a
      target="_blank"
      rel="noopener"
      href="${googleWalkingDirections(place.name)}"
    >
      Directions in Google Maps →
    </a>
  `;
}
