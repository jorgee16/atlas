export class RegionRepository {
  constructor(indexUrl = '/regions/index.json') {
    this.indexUrl = indexUrl;
    this.regions = null;
  }

  async list() {
    if (this.regions) return this.regions;

    const response = await fetch(this.indexUrl, { cache: 'no-store' });
    if (!response.ok) {
      throw new Error(`Unable to load region catalogue: HTTP ${response.status}`);
    }

    const data = await response.json();
    this.regions = data.regions ?? [];
    return this.regions;
  }

  async findByPosition(position) {
    const regions = await this.list();

    return regions.find(region => {
      const [left, bottom, right, top] = region.bounds;
      return (
        position.lon >= left &&
        position.lon <= right &&
        position.lat >= bottom &&
        position.lat <= top
      );
    }) ?? null;
  }
}
