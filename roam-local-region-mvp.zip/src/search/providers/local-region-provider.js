import { distanceMeters } from '../../utils.js';

export class LocalRegionProvider {
  constructor({ regionRepository }) {
    this.regionRepository = regionRepository;
    this.datasets = new Map();
  }

  async search(anchor, radiusMeters = 900) {
    const region = await this.regionRepository.findByPosition(anchor);

    if (!region) {
      throw new Error('No local Roam region is installed for this location.');
    }

    const features = await this.#loadRegion(region);

    return features
      .map(feature => {
        const [lon, lat] = feature.geometry.coordinates;
        const properties = feature.properties ?? {};

        return {
          id: feature.id ?? properties.osm_id,
          lat,
          lon,
          name: properties.name,
          amenity: properties.amenity ?? 'place',
          type: properties.type ?? 'attraction',
          distance: distanceMeters(anchor.lat, anchor.lon, lat, lon)
        };
      })
      .filter(place =>
        place.name &&
        Number.isFinite(place.lat) &&
        Number.isFinite(place.lon) &&
        place.distance <= radiusMeters
      )
      .sort((a, b) => a.distance - b.distance);
  }

  async #loadRegion(region) {
    if (this.datasets.has(region.id)) {
      return this.datasets.get(region.id);
    }

    const response = await fetch(region.poiUrl, { cache: 'no-store' });
    if (!response.ok) {
      throw new Error(
        `Unable to load local POIs for ${region.name}: HTTP ${response.status}`
      );
    }

    const data = await response.json();
    const features = data.features ?? [];
    this.datasets.set(region.id, features);
    return features;
  }
}
